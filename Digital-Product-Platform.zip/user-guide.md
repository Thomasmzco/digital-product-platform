# Digital Product Platform User Guide

## Introduction

Welcome to your Digital Product Platform! This comprehensive e-commerce solution allows you to sell your digital products (books and Excel financial templates) online. This guide will help you understand how to use and maintain your platform.

## System Overview

Your Digital Product Platform consists of:

1. **Frontend**: A responsive React application that provides the user interface for customers to browse, purchase, and download your digital products.

2. **Backend**: A Node.js Express server that handles all business logic, data storage, user authentication, and payment processing.

3. **Database**: MongoDB database that stores all product, user, order, and review information.

4. **Payment Processing**: Stripe integration for secure payment handling.

## Getting Started

### Accessing the Admin Dashboard

1. Navigate to your platform URL
2. Click on "Login" in the top navigation bar
3. Enter your admin credentials:
   - Email: admin@example.com
   - Password: (use the password provided separately)
4. After logging in, click on "Dashboard" to access the admin area

### Managing Products

#### Adding a New Product

1. From the admin dashboard, click on "Products" in the sidebar
2. Click the "Add New Product" button
3. Fill in the product details:
   - Title: Name of your digital product
   - Description: Detailed description of the product
   - Short Description: Brief summary for product listings
   - Type: Select "book" or "template"
   - Price: Set the price in USD
   - Categories: Assign relevant categories
   - Tags: Add searchable tags
   - Featured: Toggle if you want to feature this product on the homepage
4. Upload product files:
   - Product File: The actual digital product (PDF, XLSX, etc.)
   - Thumbnail: Image to display in product listings
5. Click "Save" to publish the product

#### Editing Existing Products

1. From the Products page, find the product you want to edit
2. Click the "Edit" button
3. Update any fields as needed
4. Click "Save" to update the product

#### Removing Products

1. From the Products page, find the product you want to remove
2. Click the "Delete" button
3. Confirm deletion when prompted

### Managing Orders

1. From the admin dashboard, click on "Orders" in the sidebar
2. View all customer orders with status information
3. Click on any order to see details including:
   - Customer information
   - Purchased products
   - Payment status
   - Download history

### Viewing Analytics

1. From the admin dashboard, click on "Analytics" in the sidebar
2. View sales reports, popular products, and customer statistics
3. Use filters to analyze data by date range, product type, etc.

## Customer Experience

Your customers will experience the following journey:

1. **Browse Products**: Customers can view all products, filter by category, or search by keywords
2. **Product Details**: Detailed information about each product with preview images
3. **Shopping Cart**: Add products and proceed to checkout
4. **Checkout**: Secure payment processing with Stripe
5. **Download**: After purchase, customers can download their digital products from their account dashboard

## Maintenance

### Regular Maintenance Tasks

1. **Database Backup**: Run weekly backups of your MongoDB database
2. **Update Product Information**: Keep product descriptions and images up to date
3. **Monitor Sales**: Regularly check the analytics dashboard for sales trends
4. **Customer Support**: Monitor and respond to customer inquiries and reviews

### Updating the Platform

To update your platform with new features or bug fixes:

1. Stop the current instance: `./deployment/scripts/stop.sh`
2. Pull the latest code updates
3. Run the build script: `./deployment/scripts/build.sh`
4. Deploy the updates: `./deployment/scripts/deploy.sh`
5. Start the platform again: `./deployment/scripts/start.sh`

## Technical Information

### System Requirements

- Node.js v16 or higher
- MongoDB v4.4 or higher
- 2GB RAM minimum (4GB recommended)
- 10GB storage space (more depending on product file sizes)

### Important Files and Directories

- `/frontend`: Contains all frontend React code
- `/backend`: Contains all backend Node.js code
- `/backend/uploads`: Stores uploaded product files
- `/deployment`: Contains deployment scripts and configuration

### Environment Variables

The platform uses the following environment variables:

- `NODE_ENV`: Set to "production" for production environment
- `PORT`: Backend server port (default: 5000)
- `MONGO_URI`: MongoDB connection string
- `JWT_SECRET`: Secret key for JWT authentication
- `JWT_EXPIRE`: JWT token expiration time
- `STRIPE_SECRET_KEY`: Your Stripe secret key
- `STRIPE_WEBHOOK_SECRET`: Your Stripe webhook secret

## Support and Troubleshooting

### Common Issues

1. **Payment Processing Errors**:
   - Verify Stripe API keys are correct
   - Check Stripe Dashboard for detailed error information

2. **File Upload Issues**:
   - Ensure the uploads directory has proper permissions
   - Verify file size is within the allowed limit

3. **Server Connection Issues**:
   - Check MongoDB connection string
   - Verify server is running with correct environment variables

### Getting Help

If you encounter issues not covered in this guide, please contact support at support@example.com.

## Conclusion

Your Digital Product Platform provides everything you need to sell your books and Excel financial templates online. With its user-friendly interface, secure payment processing, and comprehensive admin tools, you can focus on creating great digital products while the platform handles the e-commerce functionality.
