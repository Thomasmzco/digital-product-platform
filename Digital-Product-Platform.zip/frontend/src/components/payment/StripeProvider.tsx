import React from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import PaymentForm from './PaymentForm';

// Load Stripe with your publishable key
// In a real app, this would be stored in an environment variable
const stripePromise = loadStripe('pk_test_TYooMQauvdEDq54NiTphI7jx');

const StripeProvider = ({ children, order, onPaymentSuccess, onPaymentError }) => {
  const options = {
    // Passing the client secret obtained from the server
    clientSecret: null, // This will be set by the PaymentForm component
    appearance: {
      theme: 'stripe',
      variables: {
        colorPrimary: '#1976d2', // Match with MUI primary color
        colorBackground: '#ffffff',
        colorText: '#424770',
        colorDanger: '#f44336', // Match with MUI error color
        fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
        spacingUnit: '4px',
        borderRadius: '4px',
      },
    },
  };

  return (
    <Elements stripe={stripePromise} options={options}>
      {children ? (
        children
      ) : (
        <PaymentForm 
          order={order} 
          onPaymentSuccess={onPaymentSuccess} 
          onPaymentError={onPaymentError} 
        />
      )}
    </Elements>
  );
};

export default StripeProvider;
