import React from 'react';
import { AppBar, Toolbar, Typography, Button, IconButton, Badge, Container, Box } from '@mui/material';
import { ShoppingCart, Person, Menu as MenuIcon } from '@mui/icons-material';
import { Link as RouterLink } from 'react-router-dom';

const Header: React.FC = () => {
  const [cartCount, setCartCount] = React.useState(0);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <AppBar position="static" color="default" elevation={0} sx={{ borderBottom: '1px solid rgba(0, 0, 0, 0.12)' }}>
      <Container maxWidth="lg">
        <Toolbar sx={{ flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              edge="start"
              color="inherit"
              aria-label="menu"
              sx={{ mr: 2, display: { sm: 'none' } }}
              onClick={toggleMobileMenu}
            >
              <MenuIcon />
            </IconButton>
            <Typography
              variant="h6"
              color="inherit"
              noWrap
              component={RouterLink}
              to="/"
              sx={{ 
                textDecoration: 'none',
                color: 'primary.main',
                fontWeight: 700,
                letterSpacing: '.3rem'
              }}
            >
              DIGITAL STORE
            </Typography>
          </Box>

          <Box sx={{ display: { xs: mobileMenuOpen ? 'flex' : 'none', sm: 'flex' }, flexDirection: { xs: 'column', sm: 'row' }, alignItems: 'center' }}>
            <Button color="inherit" component={RouterLink} to="/" sx={{ my: { xs: 1, sm: 0 } }}>
              Home
            </Button>
            <Button color="inherit" component={RouterLink} to="/products" sx={{ my: { xs: 1, sm: 0 }, mx: { sm: 1 } }}>
              Products
            </Button>
            <Button color="inherit" component={RouterLink} to="/cart" sx={{ my: { xs: 1, sm: 0 } }}>
              <Badge badgeContent={cartCount} color="secondary" sx={{ mr: 1 }}>
                <ShoppingCart />
              </Badge>
              Cart
            </Button>
            {isLoggedIn ? (
              <Button color="inherit" component={RouterLink} to="/dashboard" sx={{ my: { xs: 1, sm: 0 }, ml: { sm: 1 } }}>
                <Person sx={{ mr: 1 }} />
                Account
              </Button>
            ) : (
              <Button color="primary" variant="contained" component={RouterLink} to="/login" sx={{ my: { xs: 1, sm: 0 }, ml: { sm: 1 } }}>
                Login
              </Button>
            )}
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Header;
