import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardMedia, 
  CardContent, 
  Button,
  Pagination,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Chip,
  Slider,
  Divider,
  Paper
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { Search as SearchIcon, FilterList as FilterIcon } from '@mui/icons-material';

const ProductsPage: React.FC = () => {
  // State for filters and pagination
  const [category, setCategory] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [priceRange, setPriceRange] = useState<number[]>([0, 100]);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Mock data for products
  const products = [
    {
      id: 1,
      title: 'Financial Planning Guide',
      type: 'book',
      price: 19.99,
      image: 'https://via.placeholder.com/300x200?text=Financial+Planning',
      slug: 'financial-planning-guide',
      category: 'books'
    },
    {
      id: 2,
      title: 'Investment Portfolio Tracker',
      type: 'template',
      price: 24.99,
      image: 'https://via.placeholder.com/300x200?text=Portfolio+Tracker',
      slug: 'investment-portfolio-tracker',
      category: 'templates'
    },
    {
      id: 3,
      title: 'Retirement Calculator',
      type: 'template',
      price: 14.99,
      image: 'https://via.placeholder.com/300x200?text=Retirement+Calculator',
      slug: 'retirement-calculator',
      category: 'templates'
    },
    {
      id: 4,
      title: 'Stock Market Basics',
      type: 'book',
      price: 29.99,
      image: 'https://via.placeholder.com/300x200?text=Stock+Market',
      slug: 'stock-market-basics',
      category: 'books'
    },
    {
      id: 5,
      title: 'Budget Planner Template',
      type: 'template',
      price: 9.99,
      image: 'https://via.placeholder.com/300x200?text=Budget+Planner',
      slug: 'budget-planner-template',
      category: 'templates'
    },
    {
      id: 6,
      title: 'Tax Planning Strategies',
      type: 'book',
      price: 34.99,
      image: 'https://via.placeholder.com/300x200?text=Tax+Planning',
      slug: 'tax-planning-strategies',
      category: 'books'
    }
  ];

  // Filter products based on selected filters
  const filteredProducts = products.filter(product => {
    // Filter by category
    if (category !== 'all' && product.category !== category) return false;
    
    // Filter by price range
    if (product.price < priceRange[0] || product.price > priceRange[1]) return false;
    
    // Filter by search query
    if (searchQuery && !product.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    
    return true;
  });

  // Sort products based on selected sort option
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    if (sortBy === 'name-asc') return a.title.localeCompare(b.title);
    if (sortBy === 'name-desc') return b.title.localeCompare(a.title);
    // Default: newest
    return b.id - a.id;
  });

  // Pagination
  const productsPerPage = 6;
  const totalPages = Math.ceil(sortedProducts.length / productsPerPage);
  const displayedProducts = sortedProducts.slice(
    (page - 1) * productsPerPage,
    page * productsPerPage
  );

  const handlePageChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    window.scrollTo(0, 0);
  };

  const handlePriceChange = (event: Event, newValue: number | number[]) => {
    setPriceRange(newValue as number[]);
  };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        All Products
      </Typography>

      {/* Search and Filter Controls */}
      <Box sx={{ mb: 4 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />,
              }}
            />
          </Grid>
          <Grid item xs={6} md={3}>
            <FormControl fullWidth>
              <InputLabel id="sort-by-label">Sort By</InputLabel>
              <Select
                labelId="sort-by-label"
                value={sortBy}
                label="Sort By"
                onChange={(e) => setSortBy(e.target.value)}
              >
                <MenuItem value="newest">Newest</MenuItem>
                <MenuItem value="price-low">Price: Low to High</MenuItem>
                <MenuItem value="price-high">Price: High to Low</MenuItem>
                <MenuItem value="name-asc">Name: A to Z</MenuItem>
                <MenuItem value="name-desc">Name: Z to A</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6} md={3}>
            <Button 
              fullWidth 
              variant="outlined" 
              startIcon={<FilterIcon />}
              onClick={toggleFilters}
            >
              Filters
            </Button>
          </Grid>
        </Grid>

        {/* Expandable Filters */}
        {showFilters && (
          <Paper sx={{ mt: 2, p: 3 }}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography gutterBottom>Category</Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  <Chip 
                    label="All" 
                    onClick={() => setCategory('all')}
                    color={category === 'all' ? 'primary' : 'default'}
                  />
                  <Chip 
                    label="Books" 
                    onClick={() => setCategory('books')}
                    color={category === 'books' ? 'primary' : 'default'}
                  />
                  <Chip 
                    label="Templates" 
                    onClick={() => setCategory('templates')}
                    color={category === 'templates' ? 'primary' : 'default'}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography gutterBottom>Price Range</Typography>
                <Slider
                  value={priceRange}
                  onChange={handlePriceChange}
                  valueLabelDisplay="auto"
                  min={0}
                  max={100}
                />
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2">${priceRange[0]}</Typography>
                  <Typography variant="body2">${priceRange[1]}</Typography>
                </Box>
              </Grid>
            </Grid>
          </Paper>
        )}
      </Box>

      {/* Product Grid */}
      {displayedProducts.length > 0 ? (
        <>
          <Grid container spacing={4}>
            {displayedProducts.map((product) => (
              <Grid item key={product.id} xs={12} sm={6} md={4}>
                <Card 
                  sx={{ 
                    height: '100%', 
                    display: 'flex', 
                    flexDirection: 'column',
                    transition: '0.3s',
                    '&:hover': {
                      transform: 'translateY(-5px)',
                      boxShadow: '0 10px 20px rgba(0,0,0,0.1)'
                    }
                  }}
                >
                  <CardMedia
                    component="img"
                    height="200"
                    image={product.image}
                    alt={product.title}
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2">
                      {product.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      {product.type === 'book' ? 'Book' : 'Excel Template'}
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="h6" color="primary">
                        ${product.price}
                      </Typography>
                      <Button 
                        variant="outlined" 
                        size="small"
                        component={RouterLink}
                        to={`/products/${product.slug}`}
                      >
                        View Details
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Pagination */}
          {totalPages > 1 && (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
              <Pagination 
                count={totalPages} 
                page={page} 
                onChange={handlePageChange} 
                color="primary" 
              />
            </Box>
          )}
        </>
      ) : (
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <Typography variant="h6" gutterBottom>
            No products found
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Try adjusting your search or filter criteria
          </Typography>
          <Button 
            variant="contained" 
            sx={{ mt: 2 }}
            onClick={() => {
              setCategory('all');
              setPriceRange([0, 100]);
              setSearchQuery('');
            }}
          >
            Clear Filters
          </Button>
        </Box>
      )}
    </Container>
  );
};

export default ProductsPage;
