import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  Button,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip
} from '@mui/material';
import { 
  Download as DownloadIcon,
  ShoppingBag as OrderIcon,
  Person as ProfileIcon,
  Favorite as WishlistIcon,
  Dashboard as DashboardIcon,
  Logout as LogoutIcon
} from '@mui/icons-material';
import { Routes, Route, Link as RouterLink, useNavigate, useLocation } from 'react-router-dom';

// Dashboard Overview Component
const DashboardOverview: React.FC = () => {
  // Mock data for recent purchases
  const recentPurchases = [
    {
      id: 1,
      title: 'Investment Portfolio Tracker',
      date: 'April 5, 2025',
      price: 24.99
    },
    {
      id: 2,
      title: 'Budget Planner Template',
      date: 'April 2, 2025',
      price: 9.99
    }
  ];

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Welcome, John Doe
      </Typography>
      <Typography variant="body1" paragraph>
        From your dashboard, you can download your purchased products, view your order history, and manage your account.
      </Typography>

      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Purchases
              </Typography>
              <List>
                {recentPurchases.map((purchase) => (
                  <ListItem key={purchase.id} divider>
                    <ListItemText
                      primary={purchase.title}
                      secondary={`Purchased on ${purchase.date}`}
                    />
                    <Typography variant="body2" color="primary">
                      ${purchase.price}
                    </Typography>
                  </ListItem>
                ))}
              </List>
              <Button 
                component={RouterLink} 
                to="/dashboard/purchases" 
                sx={{ mt: 2 }}
              >
                View All Purchases
              </Button>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Quick Downloads
              </Typography>
              <List>
                {recentPurchases.map((purchase) => (
                  <ListItem key={purchase.id} divider>
                    <ListItemText
                      primary={purchase.title}
                    />
                    <Button 
                      variant="outlined" 
                      size="small" 
                      startIcon={<DownloadIcon />}
                    >
                      Download
                    </Button>
                  </ListItem>
                ))}
              </List>
              <Button 
                component={RouterLink} 
                to="/dashboard/downloads" 
                sx={{ mt: 2 }}
              >
                View All Downloads
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

// Purchases Component
const Purchases: React.FC = () => {
  // Mock data for purchases
  const purchases = [
    {
      id: 1,
      title: 'Investment Portfolio Tracker',
      date: 'April 5, 2025',
      price: 24.99,
      orderNumber: 'ORD-2025-001'
    },
    {
      id: 2,
      title: 'Budget Planner Template',
      date: 'April 2, 2025',
      price: 9.99,
      orderNumber: 'ORD-2025-002'
    },
    {
      id: 3,
      title: 'Financial Planning Guide',
      date: 'March 15, 2025',
      price: 19.99,
      orderNumber: 'ORD-2025-003'
    }
  ];

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Purchase History
      </Typography>
      <Typography variant="body1" paragraph>
        View all your past purchases and download your products.
      </Typography>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Order Number</TableCell>
              <TableCell>Product</TableCell>
              <TableCell>Date</TableCell>
              <TableCell align="right">Price</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {purchases.map((purchase) => (
              <TableRow key={purchase.id}>
                <TableCell>{purchase.orderNumber}</TableCell>
                <TableCell>{purchase.title}</TableCell>
                <TableCell>{purchase.date}</TableCell>
                <TableCell align="right">${purchase.price}</TableCell>
                <TableCell align="right">
                  <Button 
                    variant="outlined" 
                    size="small" 
                    startIcon={<DownloadIcon />}
                  >
                    Download
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

// Downloads Component
const Downloads: React.FC = () => {
  // Mock data for downloads
  const downloads = [
    {
      id: 1,
      title: 'Investment Portfolio Tracker',
      type: 'template',
      purchaseDate: 'April 5, 2025',
      downloadCount: 2,
      fileSize: '1.2 MB'
    },
    {
      id: 2,
      title: 'Budget Planner Template',
      type: 'template',
      purchaseDate: 'April 2, 2025',
      downloadCount: 1,
      fileSize: '0.8 MB'
    },
    {
      id: 3,
      title: 'Financial Planning Guide',
      type: 'book',
      purchaseDate: 'March 15, 2025',
      downloadCount: 3,
      fileSize: '2.5 MB'
    }
  ];

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Downloads
      </Typography>
      <Typography variant="body1" paragraph>
        Access and download all your purchased digital products.
      </Typography>

      <Grid container spacing={3}>
        {downloads.map((download) => (
          <Grid item xs={12} sm={6} md={4} key={download.id}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {download.title}
                </Typography>
                <Chip 
                  label={download.type === 'book' ? 'Book' : 'Excel Template'} 
                  color="primary" 
                  size="small"
                  sx={{ mb: 2 }}
                />
                <Typography variant="body2" color="text.secondary" paragraph>
                  Purchased: {download.purchaseDate}
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  File size: {download.fileSize}
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  Downloaded {download.downloadCount} times
                </Typography>
                <Button 
                  variant="contained" 
                  fullWidth
                  startIcon={<DownloadIcon />}
                >
                  Download
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

// Profile Component
const Profile: React.FC = () => {
  // Mock user data
  const user = {
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    country: 'United States'
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Profile
      </Typography>
      <Typography variant="body1" paragraph>
        Manage your account information.
      </Typography>

      <Paper sx={{ p: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2">First Name</Typography>
            <Typography variant="body1" paragraph>{user.firstName}</Typography>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2">Last Name</Typography>
            <Typography variant="body1" paragraph>{user.lastName}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="subtitle2">Email</Typography>
            <Typography variant="body1" paragraph>{user.email}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="subtitle2">Country</Typography>
            <Typography variant="body1" paragraph>{user.country}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Button variant="contained">
              Edit Profile
            </Button>
            <Button variant="outlined" sx={{ ml: 2 }}>
              Change Password
            </Button>
          </Grid>
        </Grid>
      </Paper>
    </Box>
  );
};

// Wishlist Component
const Wishlist: React.FC = () => {
  // Mock wishlist data
  const wishlistItems = [
    {
      id: 4,
      title: 'Stock Market Basics',
      type: 'book',
      price: 29.99,
      image: 'https://via.placeholder.com/100x100?text=Stock+Market'
    },
    {
      id: 6,
      title: 'Tax Planning Strategies',
      type: 'book',
      price: 34.99,
      image: 'https://via.placeholder.com/100x100?text=Tax+Planning'
    }
  ];

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Wishlist
      </Typography>
      <Typography variant="body1" paragraph>
        Products you've saved for later.
      </Typography>

      {wishlistItems.length > 0 ? (
        <Grid container spacing={3}>
          {wishlistItems.map((item) => (
            <Grid item xs={12} key={item.id}>
              <Paper sx={{ p: 2 }}>
                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={2} sm={1}>
                    <Box 
                      component="img" 
                      src={item.image} 
                      alt={item.title}
                      sx={{ width: '100%', maxWidth: 60 }}
                    />
                  </Grid>
                  <Grid item xs={6} sm={7}>
                    <Typography variant="subtitle1">
                      {item.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {item.type === 'book' ? 'Book' : 'Excel Template'}
                    </Typography>
                  </Grid>
                  <Grid item xs={4} sm={2}>
                    <Typography variant="h6" color="primary">
                      ${item.price}
                    </Typography>
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    <Button 
                      variant="contained" 
                      fullWidth
                      size="small"
                    >
                      Add to Cart
                    </Button>
                  </Grid>
                </Grid>
              </Paper>
            </Grid>
          ))}
        </Grid>
      ) : (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="body1" paragraph>
            Your wishlist is empty.
          </Typography>
          <Button 
            variant="contained" 
            component={RouterLink} 
            to="/products"
          >
            Browse Products
          </Button>
        </Paper>
      )}
    </Box>
  );
};

// Main Dashboard Component
const DashboardPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Determine active tab based on URL path
  const getActiveTab = () => {
    const path = location.pathname;
    if (path === '/dashboard/purchases') return 1;
    if (path === '/dashboard/downloads') return 2;
    if (path === '/dashboard/profile') return 3;
    if (path === '/dashboard/wishlist') return 4;
    return 0; // Default to overview
  };
  
  const [activeTab, setActiveTab] = useState(getActiveTab());

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
    
    // Navigate to the corresponding route
    switch (newValue) {
      case 0:
        navigate('/dashboard');
        break;
      case 1:
        navigate('/dashboard/purchases');
        break;
      case 2:
        navigate('/dashboard/downloads');
        break;
      case 3:
        navigate('/dashboard/profile');
        break;
      case 4:
        navigate('/dashboard/wishlist');
        break;
      default:
        navigate('/dashboard');
    }
  };

  const handleLogout = () => {
    // In a real app, this would dispatch a logout action
    console.log('Logging out');
    navigate('/');
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        My Account
      </Typography>

      <Grid container spacing={4}>
        {/* Sidebar */}
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 2, display: { xs: 'none', md: 'block' } }}>
            <List component="nav">
              <ListItem 
                button 
                component={RouterLink} 
                to="/dashboard"
                selected={activeTab === 0}
              >
                <ListItemIcon>
                  <DashboardIcon />
                </ListItemIcon>
                <ListItemText primary="Dashboard" />
              </ListItem>
              <ListItem 
                button 
                component={RouterLink} 
                to="/dashboard/purchases"
                selected={activeTab === 1}
              >
                <ListItemIcon>
                  <OrderIcon />
                </ListItemIcon>
                <ListItemText primary="Purchases" />
              </ListItem>
              <ListItem 
                button 
                component={RouterLink} 
                to="/dashboard/downloads"
                selected={activeTab === 2}
              >
                <ListItemIcon>
                  <DownloadIcon />
                </ListItemIcon>
                <ListItemText primary="Downloads" />
              </ListItem>
              <ListItem 
                button 
                component={RouterLink} 
                to="/dashboard/profile"
                selected={activeTab === 3}
              >
                <ListItemIcon>
                  <ProfileIcon />
                </ListItemIcon>
                <ListItemText primary="Profile" />
              </ListItem>
              <ListItem 
                button 
                component={RouterLink} 
                to="/dashboard/wishlist"
                selected={activeTab === 4}
              >
                <ListItemIcon>
                  <WishlistIcon />
                </ListItemIcon>
                <ListItemText primary="Wishlist" />
              </ListItem>
              <Divider sx={{ my: 2 }} />
              <ListItem button onClick={handleLogout}>
                <ListItemIcon>
                  <LogoutIcon />
                </ListItemIcon>
                <ListItemText primary="Logout" />
              </ListItem>
            </List>
          </Paper>

          {/* Mobile Tabs */}
          <Box sx={{ display: { xs: 'block', md: 'none' }, mb: 3 }}>
            <Tabs
              value={activeTab}
              onChange={handleTabChange}
              variant="scrollable"
              scrollButtons="auto"
              aria-label="dashboard navigation tabs"
            >
              <Tab label="Dashboard" />
              <Tab label="Purchases" />
              <Tab label="Downloads" />
              <Tab label="Profile" />
              <Tab label="Wishlist" />
            </Tabs>
          </Box>
        </Grid>

        {/* Main Content */}
        <Grid item xs={12} md={9}>
          <Paper sx={{ p: 3 }}>
            <Routes>
              <Route path="/" element={<DashboardOverview />} />
              <Route path="/purchases" element={<Purchases />} />
              <Route path="/downloads" element={<Downloads />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/wishlist" element={<Wishlist />} />
            </Routes>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default DashboardPage;
