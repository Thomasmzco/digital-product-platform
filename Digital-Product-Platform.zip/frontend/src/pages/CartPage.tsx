import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  Button,
  IconButton,
  Divider,
  TextField,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction
} from '@mui/material';
import { 
  Delete as DeleteIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  ShoppingBag as ShoppingBagIcon
} from '@mui/icons-material';
import { Link as RouterLink } from 'react-router-dom';

const CartPage: React.FC = () => {
  // Mock cart data - in a real app, this would come from Redux store or context
  const [cartItems, setCartItems] = useState([
    {
      id: 2,
      title: 'Investment Portfolio Tracker',
      type: 'template',
      price: 24.99,
      image: 'https://via.placeholder.com/100x100?text=Portfolio+Tracker',
      quantity: 1
    },
    {
      id: 5,
      title: 'Budget Planner Template',
      type: 'template',
      price: 9.99,
      image: 'https://via.placeholder.com/100x100?text=Budget+Planner',
      quantity: 1
    }
  ]);

  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);

  // Calculate cart totals
  const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const total = subtotal - discount;

  const handleRemoveItem = (id: number) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const handleQuantityChange = (id: number, change: number) => {
    setCartItems(cartItems.map(item => 
      item.id === id 
        ? { ...item, quantity: Math.max(1, item.quantity + change) } 
        : item
    ));
  };

  const handleApplyCoupon = () => {
    // In a real app, this would validate the coupon code with the backend
    if (couponCode.toLowerCase() === 'discount10') {
      setDiscount(subtotal * 0.1); // 10% discount
    } else {
      setDiscount(0);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Shopping Cart
      </Typography>

      {cartItems.length > 0 ? (
        <Grid container spacing={4}>
          {/* Cart Items */}
          <Grid item xs={12} md={8}>
            <Paper sx={{ p: 3, mb: { xs: 3, md: 0 } }}>
              <List>
                {cartItems.map((item) => (
                  <React.Fragment key={item.id}>
                    <ListItem sx={{ py: 2 }}>
                      <Box sx={{ display: 'flex', width: '100%' }}>
                        <Box 
                          component="img" 
                          src={item.image} 
                          alt={item.title}
                          sx={{ width: 80, height: 80, mr: 2 }}
                        />
                        <Box sx={{ flexGrow: 1 }}>
                          <ListItemText 
                            primary={
                              <Typography variant="h6" component={RouterLink} to={`/products/${item.id}`} sx={{ textDecoration: 'none', color: 'inherit' }}>
                                {item.title}
                              </Typography>
                            }
                            secondary={
                              <Typography variant="body2" color="text.secondary">
                                {item.type === 'book' ? 'Book' : 'Excel Template'}
                              </Typography>
                            }
                          />
                          <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                            <IconButton 
                              size="small" 
                              onClick={() => handleQuantityChange(item.id, -1)}
                              disabled={item.quantity <= 1}
                            >
                              <RemoveIcon fontSize="small" />
                            </IconButton>
                            <Typography sx={{ mx: 1 }}>
                              {item.quantity}
                            </Typography>
                            <IconButton 
                              size="small" 
                              onClick={() => handleQuantityChange(item.id, 1)}
                            >
                              <AddIcon fontSize="small" />
                            </IconButton>
                          </Box>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', justifyContent: 'space-between' }}>
                          <Typography variant="h6" color="primary">
                            ${(item.price * item.quantity).toFixed(2)}
                          </Typography>
                          <IconButton 
                            edge="end" 
                            aria-label="delete"
                            onClick={() => handleRemoveItem(item.id)}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Box>
                      </Box>
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
            </Paper>
          </Grid>

          {/* Order Summary */}
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Order Summary
                </Typography>
                <Box sx={{ my: 2 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Typography variant="body1">Subtotal:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body1" align="right">${subtotal.toFixed(2)}</Typography>
                    </Grid>
                    {discount > 0 && (
                      <>
                        <Grid item xs={6}>
                          <Typography variant="body1">Discount:</Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="body1" align="right" color="error">
                            -${discount.toFixed(2)}
                          </Typography>
                        </Grid>
                      </>
                    )}
                    <Grid item xs={12}>
                      <Divider sx={{ my: 1 }} />
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="h6">Total:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="h6" align="right" color="primary">
                        ${total.toFixed(2)}
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>

                {/* Coupon Code */}
                <Box sx={{ mt: 3, mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Apply Coupon Code
                  </Typography>
                  <Box sx={{ display: 'flex' }}>
                    <TextField
                      size="small"
                      placeholder="Enter code"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      sx={{ flexGrow: 1, mr: 1 }}
                    />
                    <Button 
                      variant="outlined" 
                      onClick={handleApplyCoupon}
                    >
                      Apply
                    </Button>
                  </Box>
                </Box>

                <Button 
                  variant="contained" 
                  color="primary" 
                  fullWidth 
                  size="large"
                  component={RouterLink}
                  to="/checkout"
                  sx={{ mt: 2 }}
                >
                  Proceed to Checkout
                </Button>
                <Button 
                  variant="outlined" 
                  fullWidth 
                  component={RouterLink}
                  to="/products"
                  sx={{ mt: 2 }}
                >
                  Continue Shopping
                </Button>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      ) : (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <ShoppingBagIcon sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
          <Typography variant="h5" gutterBottom>
            Your cart is empty
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            Looks like you haven't added any products to your cart yet.
          </Typography>
          <Button 
            variant="contained" 
            component={RouterLink} 
            to="/products"
            size="large"
            sx={{ mt: 2 }}
          >
            Browse Products
          </Button>
        </Paper>
      )}
    </Container>
  );
};

export default CartPage;
