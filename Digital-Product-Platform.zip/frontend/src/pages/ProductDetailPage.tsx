import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardMedia, 
  CardContent, 
  Button,
  Tabs,
  Tab,
  Divider,
  Rating,
  TextField,
  List,
  ListItem,
  ListItemText,
  Paper,
  Chip
} from '@mui/material';
import { 
  ShoppingCart as CartIcon, 
  Download as DownloadIcon,
  Star as StarIcon
} from '@mui/icons-material';
import { useParams } from 'react-router-dom';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`product-tabpanel-${index}`}
      aria-labelledby={`product-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const ProductDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [tabValue, setTabValue] = useState(0);
  
  // Mock product data - in a real app, this would be fetched from API
  const product = {
    id: 2,
    title: 'Investment Portfolio Tracker',
    type: 'template',
    price: 24.99,
    image: 'https://via.placeholder.com/600x400?text=Portfolio+Tracker',
    slug: 'investment-portfolio-tracker',
    category: 'templates',
    description: 'A comprehensive Excel template for tracking and analyzing your investment portfolio. This template includes features for monitoring performance, calculating returns, and visualizing asset allocation.',
    details: {
      format: 'Excel (.xlsx)',
      compatibility: 'Excel 2016 or later',
      lastUpdated: 'March 15, 2025',
      fileSize: '1.2 MB'
    },
    features: [
      'Track multiple investment accounts in one place',
      'Automatic calculation of returns and performance metrics',
      'Visual dashboards with charts and graphs',
      'Asset allocation analysis',
      'Dividend tracking and reinvestment calculations',
      'Historical performance tracking'
    ],
    reviews: [
      {
        id: 1,
        user: 'Michael S.',
        rating: 5,
        date: 'February 10, 2025',
        comment: 'This template has completely transformed how I manage my investments. The dashboards are intuitive and the calculations are accurate. Highly recommended!'
      },
      {
        id: 2,
        user: 'Jennifer L.',
        rating: 4,
        date: 'January 22, 2025',
        comment: 'Great template with lots of useful features. Would be perfect if it had cryptocurrency tracking built-in.'
      }
    ],
    relatedProducts: [
      {
        id: 3,
        title: 'Retirement Calculator',
        type: 'template',
        price: 14.99,
        image: 'https://via.placeholder.com/300x200?text=Retirement+Calculator',
        slug: 'retirement-calculator'
      },
      {
        id: 5,
        title: 'Budget Planner Template',
        type: 'template',
        price: 9.99,
        image: 'https://via.placeholder.com/300x200?text=Budget+Planner',
        slug: 'budget-planner-template'
      }
    ]
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleAddToCart = () => {
    console.log('Adding to cart:', product.id);
    // In a real app, this would dispatch a Redux action or call a context function
  };

  if (!product) {
    return (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography variant="h4">Product not found</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Breadcrumbs */}
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Home &gt; {product.type === 'book' ? 'Books' : 'Templates'} &gt; {product.title}
      </Typography>

      {/* Product Overview */}
      <Grid container spacing={4}>
        {/* Product Image */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardMedia
              component="img"
              image={product.image}
              alt={product.title}
              sx={{ height: '100%', objectFit: 'cover' }}
            />
          </Card>
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            fullWidth
            sx={{ mt: 2 }}
          >
            Preview Sample
          </Button>
        </Grid>

        {/* Product Info */}
        <Grid item xs={12} md={6}>
          <Typography variant="h4" component="h1" gutterBottom>
            {product.title}
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Rating value={4.5} precision={0.5} readOnly />
            <Typography variant="body2" sx={{ ml: 1 }}>
              ({product.reviews.length} reviews)
            </Typography>
          </Box>

          <Typography variant="h5" color="primary" sx={{ mb: 3 }}>
            ${product.price}
          </Typography>

          <Chip 
            label={product.type === 'book' ? 'Book' : 'Excel Template'} 
            color="secondary" 
            size="medium"
            sx={{ mb: 3 }}
          />

          <Typography variant="body1" paragraph>
            {product.description}
          </Typography>

          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle2" gutterBottom>
              Format: {product.details.format}
            </Typography>
            <Typography variant="subtitle2" gutterBottom>
              Compatibility: {product.details.compatibility}
            </Typography>
            <Typography variant="subtitle2" gutterBottom>
              Last Updated: {product.details.lastUpdated}
            </Typography>
            <Typography variant="subtitle2">
              File Size: {product.details.fileSize}
            </Typography>
          </Box>

          <Button 
            variant="contained" 
            color="primary" 
            size="large"
            startIcon={<CartIcon />}
            fullWidth
            onClick={handleAddToCart}
            sx={{ mb: 2 }}
          >
            Add to Cart
          </Button>
        </Grid>
      </Grid>

      {/* Tabs Section */}
      <Box sx={{ mt: 6, mb: 4 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange} 
          aria-label="product tabs"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="Description" id="product-tab-0" />
          <Tab label="Features" id="product-tab-1" />
          <Tab label="Reviews" id="product-tab-2" />
        </Tabs>

        <TabPanel value={tabValue} index={0}>
          <Typography variant="body1" paragraph>
            {product.description}
          </Typography>
          <Typography variant="body1">
            This template is designed to help you track and manage your investment portfolio effectively. It provides a comprehensive solution for monitoring performance, calculating returns, and visualizing your asset allocation. Whether you're a beginner investor or a seasoned professional, this tool will help you make informed decisions about your investments.
          </Typography>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <List>
            {product.features.map((feature, index) => (
              <ListItem key={index} sx={{ py: 1 }}>
                <ListItemText primary={feature} />
              </ListItem>
            ))}
          </List>
        </TabPanel>

        <TabPanel value={tabValue} index={2}>
          {product.reviews.map((review) => (
            <Paper key={review.id} sx={{ p: 3, mb: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="subtitle1" fontWeight="bold">
                  {review.user}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {review.date}
                </Typography>
              </Box>
              <Rating value={review.rating} readOnly size="small" />
              <Typography variant="body1" sx={{ mt: 2 }}>
                {review.comment}
              </Typography>
            </Paper>
          ))}

          <Divider sx={{ my: 4 }} />

          <Typography variant="h6" gutterBottom>
            Write a Review
          </Typography>
          <Box component="form" sx={{ mt: 2 }}>
            <Box sx={{ mb: 2 }}>
              <Typography component="legend">Your Rating</Typography>
              <Rating name="user-rating" />
            </Box>
            <TextField
              fullWidth
              label="Your Review"
              multiline
              rows={4}
              margin="normal"
            />
            <Button variant="contained" sx={{ mt: 2 }}>
              Submit Review
            </Button>
          </Box>
        </TabPanel>
      </Box>

      {/* Related Products */}
      <Box sx={{ mt: 8 }}>
        <Typography variant="h5" gutterBottom>
          Related Products
        </Typography>
        <Grid container spacing={4}>
          {product.relatedProducts.map((relatedProduct) => (
            <Grid item key={relatedProduct.id} xs={12} sm={6} md={4}>
              <Card 
                sx={{ 
                  height: '100%', 
                  display: 'flex', 
                  flexDirection: 'column',
                  transition: '0.3s',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: '0 10px 20px rgba(0,0,0,0.1)'
                  }
                }}
              >
                <CardMedia
                  component="img"
                  height="200"
                  image={relatedProduct.image}
                  alt={relatedProduct.title}
                />
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography gutterBottom variant="h6" component="h3">
                    {relatedProduct.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {relatedProduct.type === 'book' ? 'Book' : 'Excel Template'}
                  </Typography>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="h6" color="primary">
                      ${relatedProduct.price}
                    </Typography>
                    <Button 
                      variant="outlined" 
                      size="small"
                      href={`/products/${relatedProduct.slug}`}
                    >
                      View Details
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Container>
  );
};

export default ProductDetailPage;
