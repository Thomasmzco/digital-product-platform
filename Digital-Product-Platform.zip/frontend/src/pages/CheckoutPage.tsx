import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  Button,
  TextField,
  Divider,
  Paper,
  Stepper,
  Step,
  StepLabel,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  FormLabel,
  Alert
} from '@mui/material';
import { 
  CreditCard as CreditCardIcon,
  Payment as PaymentIcon,
  CheckCircle as CheckCircleIcon
} from '@mui/icons-material';
import StripeProvider from '../components/payment/StripeProvider';
import PaymentForm from '../components/payment/PaymentForm';

const CheckoutPage: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    country: '',
    cardNumber: '',
    cardName: '',
    expiryDate: '',
    cvv: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [order, setOrder] = useState<any>(null);
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState('');
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Mock cart data - in a real app, this would come from Redux store or context
  const cartItems = [
    {
      id: 2,
      title: 'Investment Portfolio Tracker',
      type: 'template',
      price: 24.99,
      quantity: 1
    },
    {
      id: 5,
      title: 'Budget Planner Template',
      type: 'template',
      price: 9.99,
      quantity: 1
    }
  ];

  // Calculate cart totals
  const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const discount = 0; // In a real app, this would be calculated based on applied coupons
  const total = subtotal - discount;

  const steps = ['Billing Information', 'Payment Method', 'Confirmation'];

  const handleNext = () => {
    if (activeStep === 0) {
      // Validate billing information
      const newErrors: Record<string, string> = {};
      if (!formData.email) newErrors.email = 'Email is required';
      if (!formData.firstName) newErrors.firstName = 'First name is required';
      if (!formData.lastName) newErrors.lastName = 'Last name is required';
      if (!formData.country) newErrors.country = 'Country is required';
      
      if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        return;
      }
    } else if (activeStep === 1) {
      // For PayPal, we would redirect to PayPal here
      if (paymentMethod === 'paypal') {
        // Simulate PayPal redirect
        setPaymentProcessing(true);
        setTimeout(() => {
          setPaymentProcessing(false);
          setPaymentSuccess(true);
          setActiveStep(3); // Move to completion step
        }, 2000);
        return;
      }
    }
    
    setErrors({});
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    
    // If moving to payment step, create order
    if (activeStep === 1) {
      createOrder();
    }
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error when field is filled
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const handlePaymentMethodChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPaymentMethod(e.target.value);
  };

  // Create order in the backend
  const createOrder = () => {
    // In a real app, this would call the API to create an order
    // For this demo, we'll simulate an API response
    const mockOrder = {
      id: 'ord_' + Math.random().toString(36).substr(2, 9),
      items: cartItems.map(item => ({
        productId: item.id,
        title: item.title,
        price: item.price
      })),
      totalAmount: total,
      currency: 'USD',
      paymentMethod: paymentMethod,
      customerEmail: formData.email,
      customerName: `${formData.firstName} ${formData.lastName}`,
      billingAddress: {
        country: formData.country
      },
      createdAt: new Date().toISOString()
    };
    
    setOrder(mockOrder);
  };

  const handlePaymentSuccess = (completedOrder: any) => {
    setPaymentSuccess(true);
    setActiveStep(3); // Move to completion step
  };

  const handlePaymentError = (errorMessage: string) => {
    setPaymentError(errorMessage);
  };

  const renderBillingInformation = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <TextField
          required
          fullWidth
          label="Email Address"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          error={!!errors.email}
          helperText={errors.email}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          required
          fullWidth
          label="First Name"
          name="firstName"
          value={formData.firstName}
          onChange={handleInputChange}
          error={!!errors.firstName}
          helperText={errors.firstName}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          required
          fullWidth
          label="Last Name"
          name="lastName"
          value={formData.lastName}
          onChange={handleInputChange}
          error={!!errors.lastName}
          helperText={errors.lastName}
        />
      </Grid>
      <Grid item xs={12}>
        <TextField
          required
          fullWidth
          label="Country"
          name="country"
          value={formData.country}
          onChange={handleInputChange}
          error={!!errors.country}
          helperText={errors.country}
        />
      </Grid>
    </Grid>
  );

  const renderPaymentMethod = () => (
    <Box>
      <FormControl component="fieldset" sx={{ mb: 3 }}>
        <FormLabel component="legend">Payment Method</FormLabel>
        <RadioGroup
          name="paymentMethod"
          value={paymentMethod}
          onChange={handlePaymentMethodChange}
        >
          <FormControlLabel 
            value="credit-card" 
            control={<Radio />} 
            label={
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <CreditCardIcon sx={{ mr: 1 }} />
                <Typography>Credit Card</Typography>
              </Box>
            } 
          />
          <FormControlLabel 
            value="paypal" 
            control={<Radio />} 
            label={
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <PaymentIcon sx={{ mr: 1 }} />
                <Typography>PayPal</Typography>
              </Box>
            } 
          />
        </RadioGroup>
      </FormControl>

      {paymentMethod === 'paypal' && (
        <Alert severity="info" sx={{ mt: 2 }}>
          You will be redirected to PayPal to complete your payment after reviewing your order.
        </Alert>
      )}
    </Box>
  );

  const renderOrderReview = () => (
    <Box>
      <Typography variant="h6" gutterBottom>
        Order Summary
      </Typography>
      
      {cartItems.map((item) => (
        <Box key={item.id} sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography>
            {item.title} ({item.quantity})
          </Typography>
          <Typography>
            ${(item.price * item.quantity).toFixed(2)}
          </Typography>
        </Box>
      ))}
      
      <Divider sx={{ my: 2 }} />
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
        <Typography>Subtotal</Typography>
        <Typography>${subtotal.toFixed(2)}</Typography>
      </Box>
      
      {discount > 0 && (
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
          <Typography>Discount</Typography>
          <Typography color="error">-${discount.toFixed(2)}</Typography>
        </Box>
      )}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6">Total</Typography>
        <Typography variant="h6" color="primary">${total.toFixed(2)}</Typography>
      </Box>
      
      <Divider sx={{ my: 2 }} />
      
      <Typography variant="h6" gutterBottom>
        Billing Information
      </Typography>
      <Typography>
        {formData.firstName} {formData.lastName}
      </Typography>
      <Typography>
        {formData.email}
      </Typography>
      <Typography>
        {formData.country}
      </Typography>
      
      <Divider sx={{ my: 2 }} />
      
      <Typography variant="h6" gutterBottom>
        Payment Method
      </Typography>
      <Typography>
        {paymentMethod === 'credit-card' ? 'Credit Card' : 'PayPal'}
      </Typography>
      
      {paymentMethod === 'credit-card' && order && (
        <Box sx={{ mt: 3 }}>
          <StripeProvider order={order} onPaymentSuccess={handlePaymentSuccess} onPaymentError={handlePaymentError}>
            <PaymentForm order={order} onPaymentSuccess={handlePaymentSuccess} onPaymentError={handlePaymentError} />
          </StripeProvider>
          
          {paymentError && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {paymentError}
            </Alert>
          )}
        </Box>
      )}
    </Box>
  );

  const renderOrderComplete = () => (
    <Box sx={{ textAlign: 'center', py: 4 }}>
      <CheckCircleIcon sx={{ fontSize: 60, color: 'success.main', mb: 2 }} />
      <Typography variant="h5" gutterBottom>
        Thank you for your order!
      </Typography>
      <Typography variant="body1" paragraph>
        Your order has been placed successfully. You will receive an email confirmation shortly.
      </Typography>
      <Typography variant="body1" paragraph>
        Your digital products will be available for download in your account dashboard.
      </Typography>
      <Button 
        variant="contained" 
        color="primary" 
        href="/dashboard"
        sx={{ mt: 2 }}
      >
        Go to Dashboard
      </Button>
    </Box>
  );

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Checkout
      </Typography>

      <Paper sx={{ p: 3, mb: 4 }}>
        {activeStep < 3 ? (
          <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
        ) : null}

        {activeStep === 0 && renderBillingInformation()}
        {activeStep === 1 && renderPaymentMethod()}
        {activeStep === 2 && renderOrderReview()}
        {activeStep === 3 && renderOrderComplete()}

        {activeStep < 3 && (
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
            {activeStep > 0 && (
              <Button onClick={handleBack} sx={{ mr: 1 }}>
                Back
              </Button>
            )}
            {activeStep < 2 ? (
              <Button
                variant="contained"
                onClick={handleNext}
              >
                Next
              </Button>
            ) : (
              paymentMethod === 'paypal' && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleNext}
                  disabled={paymentProcessing}
                >
                  {paymentProcessing ? 'Processing...' : 'Pay with PayPal'}
                </Button>
              )
            )}
          </Box>
        )}
      </Paper>

      {activeStep < 3 && (
        <Card sx={{ mt: 3 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Order Summary
            </Typography>
            
            {cartItems.map((item) => (
              <Box key={item.id} sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">
                  {item.title} ({item.quantity})
                </Typography>
                <Typography variant="body2">
                  ${(item.price * item.quantity).toFixed(2)}
                </Typography>
              </Box>
            ))}
            
            <Divider sx={{ my: 2 }} />
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="subtitle1">Total</Typography>
              <Typography variant="subtitle1" color="primary">${total.toFixed(2)}</Typography>
            </Box>
          </CardContent>
        </Card>
      )}
    </Container>
  );
};

export default CheckoutPage;
