import React from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardMedia, 
  CardContent, 
  Button, 
  Paper,
  Divider
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

const HomePage: React.FC = () => {
  // Mock data for featured products
  const featuredProducts = [
    {
      id: 1,
      title: 'Financial Planning Guide',
      type: 'book',
      price: 19.99,
      image: 'https://via.placeholder.com/300x200?text=Financial+Planning',
      slug: 'financial-planning-guide'
    },
    {
      id: 2,
      title: 'Investment Portfolio Tracker',
      type: 'template',
      price: 24.99,
      image: 'https://via.placeholder.com/300x200?text=Portfolio+Tracker',
      slug: 'investment-portfolio-tracker'
    },
    {
      id: 3,
      title: 'Retirement Calculator',
      type: 'template',
      price: 14.99,
      image: 'https://via.placeholder.com/300x200?text=Retirement+Calculator',
      slug: 'retirement-calculator'
    }
  ];

  // Mock data for categories
  const categories = [
    {
      id: 1,
      name: 'Books',
      image: 'https://via.placeholder.com/200x150?text=Books',
      slug: 'books'
    },
    {
      id: 2,
      name: 'Templates',
      image: 'https://via.placeholder.com/200x150?text=Templates',
      slug: 'templates'
    },
    {
      id: 3,
      name: 'New Releases',
      image: 'https://via.placeholder.com/200x150?text=New+Releases',
      slug: 'new-releases'
    }
  ];

  // Mock testimonials
  const testimonials = [
    {
      id: 1,
      name: 'John D.',
      text: 'The financial templates have saved me hours of work. Highly recommended!',
      rating: 5
    },
    {
      id: 2,
      name: 'Sarah M.',
      text: 'The books are well-written and provide valuable insights for financial planning.',
      rating: 4
    }
  ];

  return (
    <Box>
      {/* Hero Banner */}
      <Paper 
        sx={{
          position: 'relative',
          backgroundColor: 'grey.800',
          color: '#fff',
          mb: 4,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center',
          backgroundImage: 'url(https://via.placeholder.com/1200x400?text=Digital+Products)',
          height: '400px',
          display: 'flex',
          alignItems: 'center'
        }}
      >
        <Container maxWidth="lg">
          <Box sx={{ p: { xs: 2, md: 6 } }}>
            <Typography component="h1" variant="h2" color="inherit" gutterBottom>
              Premium Digital Products
            </Typography>
            <Typography variant="h5" color="inherit" paragraph>
              High-quality books and Excel financial templates to help you succeed
            </Typography>
            <Button 
              variant="contained" 
              color="secondary" 
              size="large"
              component={RouterLink}
              to="/products"
              sx={{ mt: 2 }}
            >
              Browse Products
            </Button>
          </Box>
        </Container>
      </Paper>

      {/* Featured Products */}
      <Container maxWidth="lg">
        <Typography variant="h4" component="h2" gutterBottom sx={{ mb: 4 }}>
          Featured Products
        </Typography>
        <Grid container spacing={4}>
          {featuredProducts.map((product) => (
            <Grid item key={product.id} xs={12} sm={6} md={4}>
              <Card 
                sx={{ 
                  height: '100%', 
                  display: 'flex', 
                  flexDirection: 'column',
                  transition: '0.3s',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: '0 10px 20px rgba(0,0,0,0.1)'
                  }
                }}
              >
                <CardMedia
                  component="img"
                  height="200"
                  image={product.image}
                  alt={product.title}
                />
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography gutterBottom variant="h5" component="h3">
                    {product.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {product.type === 'book' ? 'Book' : 'Excel Template'}
                  </Typography>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="h6" color="primary">
                      ${product.price}
                    </Typography>
                    <Button 
                      variant="outlined" 
                      size="small"
                      component={RouterLink}
                      to={`/products/${product.slug}`}
                    >
                      View Details
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Categories */}
        <Box sx={{ my: 8 }}>
          <Typography variant="h4" component="h2" gutterBottom sx={{ mb: 4 }}>
            Categories
          </Typography>
          <Grid container spacing={4}>
            {categories.map((category) => (
              <Grid item key={category.id} xs={12} sm={4}>
                <Card 
                  component={RouterLink} 
                  to={`/products?category=${category.slug}`}
                  sx={{ 
                    textDecoration: 'none',
                    transition: '0.3s',
                    '&:hover': {
                      transform: 'scale(1.03)',
                    }
                  }}
                >
                  <CardMedia
                    component="img"
                    height="150"
                    image={category.image}
                    alt={category.name}
                  />
                  <CardContent sx={{ textAlign: 'center' }}>
                    <Typography gutterBottom variant="h5" component="h3">
                      {category.name}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>

        {/* Testimonials */}
        <Box sx={{ my: 8 }}>
          <Typography variant="h4" component="h2" gutterBottom sx={{ mb: 4 }}>
            What Our Customers Say
          </Typography>
          <Grid container spacing={4}>
            {testimonials.map((testimonial) => (
              <Grid item key={testimonial.id} xs={12} md={6}>
                <Paper sx={{ p: 3, height: '100%' }}>
                  <Typography variant="body1" paragraph sx={{ fontStyle: 'italic' }}>
                    "{testimonial.text}"
                  </Typography>
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                    {testimonial.name}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Box>

        {/* Newsletter Signup */}
        <Box sx={{ my: 8, py: 4, backgroundColor: 'primary.light', borderRadius: 2, color: 'white' }}>
          <Container maxWidth="md" sx={{ textAlign: 'center' }}>
            <Typography variant="h4" component="h2" gutterBottom>
              Stay Updated
            </Typography>
            <Typography variant="body1" paragraph>
              Subscribe to our newsletter to receive updates on new products and special offers.
            </Typography>
            <Box 
              component="form" 
              sx={{ 
                display: 'flex', 
                flexDirection: { xs: 'column', sm: 'row' }, 
                gap: 2,
                maxWidth: '500px',
                mx: 'auto',
                mt: 3
              }}
            >
              <input 
                type="email" 
                placeholder="Your email address" 
                style={{ 
                  flex: 1, 
                  padding: '10px 16px', 
                  borderRadius: '4px',
                  border: 'none',
                  fontSize: '16px'
                }} 
              />
              <Button variant="contained" color="secondary" size="large">
                Subscribe
              </Button>
            </Box>
          </Container>
        </Box>
      </Container>
    </Box>
  );
};

export default HomePage;
