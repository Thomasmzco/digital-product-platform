const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  getOrders,
  getOrder,
  createOrder,
  updateOrder
} = require('../controllers/orders');

// Protected routes
router.get('/', protect, getOrders);
router.get('/:id', protect, getOrder);
router.post('/', protect, createOrder);

// Admin only routes
router.put('/:id', protect, authorize('admin'), updateOrder);

module.exports = router;
