const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  getUsers,
  getMe,
  updateProfile,
  getPurchases,
  getDownloads,
  addToCart,
  getCart,
  removeFromCart,
  clearCart,
  addToWishlist,
  getWishlist,
  removeFromWishlist
} = require('../controllers/users');

// Protected routes
router.get('/me', protect, getMe);
router.put('/me', protect, updateProfile);
router.get('/purchases', protect, getPurchases);
router.get('/downloads', protect, getDownloads);

// Cart routes
router.get('/cart', protect, getCart);
router.post('/cart', protect, addToCart);
router.delete('/cart/:productId', protect, removeFromCart);
router.delete('/cart', protect, clearCart);

// Wishlist routes
router.get('/wishlist', protect, getWishlist);
router.post('/wishlist', protect, addToWishlist);
router.delete('/wishlist/:productId', protect, removeFromWishlist);

// Admin only routes
router.get('/', protect, authorize('admin'), getUsers);

module.exports = router;
