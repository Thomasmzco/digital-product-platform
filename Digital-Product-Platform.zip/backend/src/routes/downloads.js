const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const path = require('path');
const crypto = require('crypto');
const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const User = require('../models/User');
const Product = require('../models/Product');

// @desc    Generate secure download link for purchased product
// @route   GET /api/downloads/:productId
// @access  Private
router.get('/:productId', protect, asyncHandler(async (req, res, next) => {
  const productId = req.params.productId;
  const userId = req.user.id;
  
  // Check if user has purchased the product
  const user = await User.findById(userId);
  const purchase = user.purchases.find(
    p => p.productId.toString() === productId
  );
  
  if (!purchase) {
    return next(
      new ErrorResponse('You have not purchased this product', 401)
    );
  }
  
  // Get product details
  const product = await Product.findById(productId);
  
  if (!product) {
    return next(
      new ErrorResponse('Product not found', 404)
    );
  }
  
  // Generate a temporary download token
  const downloadToken = crypto.randomBytes(20).toString('hex');
  
  // Store token in user's purchase record
  purchase.downloadCount += 1;
  await user.save();
  
  // Generate download URL
  // In a real production app, this would use signed URLs with expiration
  // For this demo, we'll use a simple token-based approach
  const downloadUrl = `/uploads/${path.basename(product.fileUrl)}`;
  
  res.status(200).json({
    success: true,
    data: {
      downloadUrl,
      fileName: path.basename(product.fileUrl),
      fileSize: product.fileSize
    }
  });
}));

module.exports = router;
