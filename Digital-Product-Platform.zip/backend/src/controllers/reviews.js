const Review = require('../models/Review');
const Product = require('../models/Product');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc    Get reviews for a product
// @route   GET /api/reviews/product/:productId
// @access  Public
exports.getProductReviews = asyncHandler(async (req, res, next) => {
  const reviews = await Review.find({ 
    productId: req.params.productId,
    status: 'approved'
  }).sort('-createdAt');

  res.status(200).json({
    success: true,
    count: reviews.length,
    data: reviews
  });
});

// @desc    Get all reviews
// @route   GET /api/reviews
// @access  Private (Admin)
exports.getReviews = asyncHandler(async (req, res, next) => {
  // Add pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;
  const total = await Review.countDocuments();

  const reviews = await Review.find()
    .skip(startIndex)
    .limit(limit)
    .sort('-createdAt');

  // Pagination result
  const pagination = {};

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit
    };
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit
    };
  }

  res.status(200).json({
    success: true,
    count: reviews.length,
    pagination,
    data: reviews
  });
});

// @desc    Create new review
// @route   POST /api/reviews
// @access  Private
exports.createReview = asyncHandler(async (req, res, next) => {
  // Check if product exists
  const product = await Product.findById(req.body.productId);

  if (!product) {
    return next(
      new ErrorResponse(`Product not found with id of ${req.body.productId}`, 404)
    );
  }

  // Check if user has purchased the product
  const user = req.user;
  const hasPurchased = user.purchases.some(
    purchase => purchase.productId.toString() === req.body.productId
  );

  if (!hasPurchased && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`You must purchase this product before reviewing it`, 401)
    );
  }

  // Check if user has already reviewed this product
  const existingReview = await Review.findOne({
    userId: req.user.id,
    productId: req.body.productId
  });

  if (existingReview) {
    return next(
      new ErrorResponse(`You have already reviewed this product`, 400)
    );
  }

  // Add user data to request body
  req.body.userId = req.user.id;
  req.body.userName = `${req.user.firstName} ${req.user.lastName}`;

  // Auto-approve reviews from admins
  if (req.user.role === 'admin') {
    req.body.status = 'approved';
  }

  const review = await Review.create(req.body);

  res.status(201).json({
    success: true,
    data: review
  });
});

// @desc    Update review
// @route   PUT /api/reviews/:id
// @access  Private
exports.updateReview = asyncHandler(async (req, res, next) => {
  let review = await Review.findById(req.params.id);

  if (!review) {
    return next(
      new ErrorResponse(`Review not found with id of ${req.params.id}`, 404)
    );
  }

  // Make sure user is review owner or admin
  if (review.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`Not authorized to update this review`, 401)
    );
  }

  // Only allow updating specific fields
  const allowedUpdates = {};
  
  if (req.user.role === 'admin') {
    // Admin can update status
    if (req.body.status) allowedUpdates.status = req.body.status;
  }
  
  if (review.userId.toString() === req.user.id) {
    // Owner can update rating, title, and content
    if (req.body.rating) allowedUpdates.rating = req.body.rating;
    if (req.body.title) allowedUpdates.title = req.body.title;
    if (req.body.content) allowedUpdates.content = req.body.content;
    
    // Reset status to pending if content is changed
    if (req.body.rating || req.body.title || req.body.content) {
      allowedUpdates.status = 'pending';
    }
  }

  review = await Review.findByIdAndUpdate(req.params.id, allowedUpdates, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: review
  });
});

// @desc    Delete review
// @route   DELETE /api/reviews/:id
// @access  Private
exports.deleteReview = asyncHandler(async (req, res, next) => {
  const review = await Review.findById(req.params.id);

  if (!review) {
    return next(
      new ErrorResponse(`Review not found with id of ${req.params.id}`, 404)
    );
  }

  // Make sure user is review owner or admin
  if (review.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`Not authorized to delete this review`, 401)
    );
  }

  await review.deleteOne();

  res.status(200).json({
    success: true,
    data: {}
  });
});
