const User = require('../models/User');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc    Get all users
// @route   GET /api/users
// @access  Private (Admin)
exports.getUsers = asyncHandler(async (req, res, next) => {
  // Add pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;
  const total = await User.countDocuments();

  const users = await User.find()
    .skip(startIndex)
    .limit(limit)
    .sort('-createdAt');

  // Pagination result
  const pagination = {};

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit
    };
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit
    };
  }

  res.status(200).json({
    success: true,
    count: users.length,
    pagination,
    data: users
  });
});

// @desc    Get current user
// @route   GET /api/users/me
// @access  Private
exports.getMe = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id);

  res.status(200).json({
    success: true,
    data: user
  });
});

// @desc    Update user profile
// @route   PUT /api/users/me
// @access  Private
exports.updateProfile = asyncHandler(async (req, res, next) => {
  // Only allow specific fields to be updated
  const fieldsToUpdate = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email
  };

  const user = await User.findByIdAndUpdate(req.user.id, fieldsToUpdate, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: user
  });
});

// @desc    Get user's purchase history
// @route   GET /api/users/purchases
// @access  Private
exports.getPurchases = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id).populate({
    path: 'purchases.productId',
    select: 'title type price thumbnailUrl fileUrl'
  });

  res.status(200).json({
    success: true,
    count: user.purchases.length,
    data: user.purchases
  });
});

// @desc    Get user's downloadable products
// @route   GET /api/users/downloads
// @access  Private
exports.getDownloads = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id).populate({
    path: 'purchases.productId',
    select: 'title type price thumbnailUrl fileUrl fileSize metadata'
  });

  // Filter out purchases where the product no longer exists
  const downloads = user.purchases.filter(purchase => purchase.productId);

  res.status(200).json({
    success: true,
    count: downloads.length,
    data: downloads
  });
});

// @desc    Add product to user's cart
// @route   POST /api/users/cart
// @access  Private
exports.addToCart = asyncHandler(async (req, res, next) => {
  const { productId } = req.body;

  if (!productId) {
    return next(new ErrorResponse('Please provide a product ID', 400));
  }

  const user = await User.findById(req.user.id);

  // Check if product is already in cart
  const isInCart = user.cart.some(item => item.productId.toString() === productId);

  if (isInCart) {
    return next(new ErrorResponse('Product is already in cart', 400));
  }

  user.cart.push({
    productId,
    addedAt: Date.now()
  });

  await user.save();

  res.status(200).json({
    success: true,
    data: user.cart
  });
});

// @desc    Get user's cart
// @route   GET /api/users/cart
// @access  Private
exports.getCart = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id).populate({
    path: 'cart.productId',
    select: 'title type price thumbnailUrl'
  });

  // Filter out cart items where the product no longer exists
  const cart = user.cart.filter(item => item.productId);

  res.status(200).json({
    success: true,
    count: cart.length,
    data: cart
  });
});

// @desc    Remove product from user's cart
// @route   DELETE /api/users/cart/:productId
// @access  Private
exports.removeFromCart = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id);

  // Filter out the product to remove
  user.cart = user.cart.filter(
    item => item.productId.toString() !== req.params.productId
  );

  await user.save();

  res.status(200).json({
    success: true,
    data: user.cart
  });
});

// @desc    Clear user's cart
// @route   DELETE /api/users/cart
// @access  Private
exports.clearCart = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id);

  user.cart = [];
  await user.save();

  res.status(200).json({
    success: true,
    data: user.cart
  });
});

// @desc    Add product to user's wishlist
// @route   POST /api/users/wishlist
// @access  Private
exports.addToWishlist = asyncHandler(async (req, res, next) => {
  const { productId } = req.body;

  if (!productId) {
    return next(new ErrorResponse('Please provide a product ID', 400));
  }

  const user = await User.findById(req.user.id);

  // Check if product is already in wishlist
  const isInWishlist = user.wishlist.some(id => id.toString() === productId);

  if (isInWishlist) {
    return next(new ErrorResponse('Product is already in wishlist', 400));
  }

  user.wishlist.push(productId);
  await user.save();

  res.status(200).json({
    success: true,
    data: user.wishlist
  });
});

// @desc    Get user's wishlist
// @route   GET /api/users/wishlist
// @access  Private
exports.getWishlist = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id).populate({
    path: 'wishlist',
    select: 'title type price thumbnailUrl'
  });

  // Filter out wishlist items where the product no longer exists
  const wishlist = user.wishlist.filter(product => product);

  res.status(200).json({
    success: true,
    count: wishlist.length,
    data: wishlist
  });
});

// @desc    Remove product from user's wishlist
// @route   DELETE /api/users/wishlist/:productId
// @access  Private
exports.removeFromWishlist = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id);

  // Filter out the product to remove
  user.wishlist = user.wishlist.filter(
    id => id.toString() !== req.params.productId
  );

  await user.save();

  res.status(200).json({
    success: true,
    data: user.wishlist
  });
});
