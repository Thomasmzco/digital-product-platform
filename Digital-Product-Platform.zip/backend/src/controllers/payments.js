const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Order = require('../models/Order');
const User = require('../models/User');
const Product = require('../models/Product');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc    Create a payment intent
// @route   POST /api/payments/create-payment-intent
// @access  Private
exports.createPaymentIntent = asyncHandler(async (req, res, next) => {
  const { orderId } = req.body;
  
  if (!orderId) {
    return next(new ErrorResponse('Please provide an order ID', 400));
  }
  
  const order = await Order.findById(orderId);
  
  if (!order) {
    return next(new ErrorResponse('Order not found', 404));
  }
  
  // Make sure user owns the order
  if (order.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse('Not authorized to access this order', 401));
  }
  
  // Check if order is already paid
  if (order.paymentStatus === 'completed') {
    return next(new ErrorResponse('This order has already been paid', 400));
  }
  
  // Create a payment intent with the order amount and currency
  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(order.totalAmount * 100), // Stripe requires amount in cents
    currency: order.currency.toLowerCase(),
    metadata: {
      orderId: order._id.toString(),
      userId: req.user.id
    }
  });
  
  // Update order with payment intent ID
  await Order.findByIdAndUpdate(orderId, {
    paymentId: paymentIntent.id
  });
  
  res.status(200).json({
    success: true,
    clientSecret: paymentIntent.client_secret
  });
});

// @desc    Handle successful payment
// @route   POST /api/payments/success
// @access  Private
exports.handlePaymentSuccess = asyncHandler(async (req, res, next) => {
  const { paymentIntentId } = req.body;
  
  if (!paymentIntentId) {
    return next(new ErrorResponse('Please provide a payment intent ID', 400));
  }
  
  // Verify the payment intent with Stripe
  const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
  
  if (paymentIntent.status !== 'succeeded') {
    return next(new ErrorResponse('Payment has not been completed', 400));
  }
  
  const orderId = paymentIntent.metadata.orderId;
  
  // Update order status
  const order = await Order.findByIdAndUpdate(orderId, {
    paymentStatus: 'completed'
  }, { new: true });
  
  if (!order) {
    return next(new ErrorResponse('Order not found', 404));
  }
  
  res.status(200).json({
    success: true,
    data: order
  });
});

// @desc    Handle Stripe webhook events
// @route   POST /api/payments/webhook
// @access  Public
exports.handleWebhook = asyncHandler(async (req, res, next) => {
  const sig = req.headers['stripe-signature'];
  let event;
  
  try {
    event = stripe.webhooks.constructEvent(
      req.rawBody, 
      sig, 
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  
  // Handle the event
  switch (event.type) {
    case 'payment_intent.succeeded':
      const paymentIntent = event.data.object;
      await handleSuccessfulPayment(paymentIntent);
      break;
    case 'payment_intent.payment_failed':
      const failedPayment = event.data.object;
      await handleFailedPayment(failedPayment);
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }
  
  // Return a 200 response to acknowledge receipt of the event
  res.status(200).json({ received: true });
});

// Helper function to handle successful payment
const handleSuccessfulPayment = async (paymentIntent) => {
  const orderId = paymentIntent.metadata.orderId;
  
  // Update order status
  await Order.findByIdAndUpdate(orderId, {
    paymentStatus: 'completed'
  });
  
  // Get order details
  const order = await Order.findById(orderId);
  
  // Update product sales count
  for (const item of order.items) {
    await Product.findByIdAndUpdate(item.productId, {
      $inc: { salesCount: 1 }
    });
  }
};

// Helper function to handle failed payment
const handleFailedPayment = async (paymentIntent) => {
  const orderId = paymentIntent.metadata.orderId;
  
  // Update order status
  await Order.findByIdAndUpdate(orderId, {
    paymentStatus: 'failed'
  });
};
