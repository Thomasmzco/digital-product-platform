const Order = require('../models/Order');
const Product = require('../models/Product');
const User = require('../models/User');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc    Get all orders
// @route   GET /api/orders
// @access  Private (Admin gets all, Users get their own)
exports.getOrders = asyncHandler(async (req, res, next) => {
  let query;

  // If user is not admin, they can only see their own orders
  if (req.user.role !== 'admin') {
    query = Order.find({ userId: req.user.id });
  } else {
    query = Order.find();
  }

  // Add pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;
  const total = await Order.countDocuments();

  query = query.skip(startIndex).limit(limit).sort('-createdAt');

  // Execute query
  const orders = await query;

  // Pagination result
  const pagination = {};

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit
    };
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit
    };
  }

  res.status(200).json({
    success: true,
    count: orders.length,
    pagination,
    data: orders
  });
});

// @desc    Get single order
// @route   GET /api/orders/:id
// @access  Private
exports.getOrder = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id);

  if (!order) {
    return next(
      new ErrorResponse(`Order not found with id of ${req.params.id}`, 404)
    );
  }

  // Make sure user is order owner or admin
  if (order.userId.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`Not authorized to access this order`, 401)
    );
  }

  res.status(200).json({
    success: true,
    data: order
  });
});

// @desc    Create new order
// @route   POST /api/orders
// @access  Private
exports.createOrder = asyncHandler(async (req, res, next) => {
  req.body.userId = req.user.id;
  
  // Validate items in order
  if (!req.body.items || req.body.items.length === 0) {
    return next(new ErrorResponse('Please add at least one item to the order', 400));
  }

  // Calculate total amount and populate item details
  let totalAmount = 0;
  const orderItems = [];

  for (const item of req.body.items) {
    const product = await Product.findById(item.productId);
    
    if (!product) {
      return next(
        new ErrorResponse(`Product not found with id of ${item.productId}`, 404)
      );
    }

    // Use sale price if available, otherwise use regular price
    const price = product.salePrice || product.price;
    
    totalAmount += price;
    
    orderItems.push({
      productId: product._id,
      title: product.title,
      price: price,
      currency: product.currency
    });
  }

  // Create order with calculated total and populated items
  const orderData = {
    userId: req.user.id,
    items: orderItems,
    totalAmount,
    currency: 'USD', // Default currency
    paymentMethod: req.body.paymentMethod,
    customerEmail: req.user.email,
    customerName: `${req.user.firstName} ${req.user.lastName}`,
    billingAddress: req.body.billingAddress
  };

  const order = await Order.create(orderData);

  // Update user's purchases
  const user = await User.findById(req.user.id);
  
  for (const item of orderItems) {
    user.purchases.push({
      productId: item.productId,
      purchaseDate: Date.now()
    });
  }
  
  await user.save();

  // Update product sales count
  for (const item of orderItems) {
    await Product.findByIdAndUpdate(item.productId, {
      $inc: { salesCount: 1 }
    });
  }

  res.status(201).json({
    success: true,
    data: order
  });
});

// @desc    Update order status
// @route   PUT /api/orders/:id
// @access  Private (Admin)
exports.updateOrder = asyncHandler(async (req, res, next) => {
  let order = await Order.findById(req.params.id);

  if (!order) {
    return next(
      new ErrorResponse(`Order not found with id of ${req.params.id}`, 404)
    );
  }

  // Only allow updating specific fields
  const allowedUpdates = {
    paymentStatus: req.body.paymentStatus,
    paymentId: req.body.paymentId
  };

  order = await Order.findByIdAndUpdate(req.params.id, allowedUpdates, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: order
  });
});
