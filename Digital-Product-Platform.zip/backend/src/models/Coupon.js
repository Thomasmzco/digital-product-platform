const mongoose = require('mongoose');

const CouponSchema = new mongoose.Schema({
  code: {
    type: String,
    required: [true, 'Coupon code is required'],
    unique: true,
    trim: true,
    uppercase: true
  },
  type: {
    type: String,
    enum: ['percentage', 'fixed'],
    required: true
  },
  value: {
    type: Number,
    required: [true, 'Coupon value is required'],
    min: [0, 'Value must be a positive number']
  },
  minPurchase: {
    type: Number,
    min: [0, 'Minimum purchase must be a positive number']
  },
  maxUses: {
    type: Number,
    min: [0, 'Maximum uses must be a positive number']
  },
  usedCount: {
    type: Number,
    default: 0
  },
  productIds: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product'
  }],
  startDate: {
    type: Date,
    default: Date.now
  },
  endDate: {
    type: Date
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'expired'],
    default: 'active'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field on save
CouponSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Check if coupon is valid
CouponSchema.methods.isValid = function() {
  // Check if coupon is active
  if (this.status !== 'active') {
    return false;
  }
  
  // Check if coupon has reached max uses
  if (this.maxUses && this.usedCount >= this.maxUses) {
    return false;
  }
  
  // Check if coupon is within date range
  const now = new Date();
  if (this.startDate > now) {
    return false;
  }
  
  if (this.endDate && this.endDate < now) {
    return false;
  }
  
  return true;
};

module.exports = mongoose.model('Coupon', CouponSchema);
