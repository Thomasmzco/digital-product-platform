const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Product title is required'],
    trim: true,
    maxlength: [100, 'Title cannot be more than 100 characters']
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  description: {
    type: String,
    required: [true, 'Product description is required'],
    maxlength: [5000, 'Description cannot be more than 5000 characters']
  },
  shortDescription: {
    type: String,
    maxlength: [200, 'Short description cannot be more than 200 characters']
  },
  type: {
    type: String,
    required: true,
    enum: ['book', 'template'],
    default: 'template'
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price must be a positive number']
  },
  salePrice: {
    type: Number,
    min: [0, 'Sale price must be a positive number']
  },
  currency: {
    type: String,
    default: 'USD'
  },
  fileUrl: {
    type: String,
    required: [true, 'Product file URL is required']
  },
  fileSize: {
    type: Number,
    required: [true, 'File size is required']
  },
  previewUrl: {
    type: String
  },
  thumbnailUrl: {
    type: String,
    required: [true, 'Product thumbnail URL is required']
  },
  categories: [{
    type: String,
    required: true
  }],
  tags: [{
    type: String
  }],
  featured: {
    type: Boolean,
    default: false
  },
  publishedAt: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['draft', 'published', 'archived'],
    default: 'draft'
  },
  salesCount: {
    type: Number,
    default: 0
  },
  metadata: {
    pageCount: Number,
    format: String,
    compatibility: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field on save
ProductSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Create slug from title
ProductSchema.pre('save', function(next) {
  if (!this.isModified('title')) {
    next();
    return;
  }
  
  this.slug = this.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  
  next();
});

module.exports = mongoose.model('Product', ProductSchema);
