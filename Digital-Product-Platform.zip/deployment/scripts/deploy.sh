#!/bin/bash

# Deployment script for Digital Product Platform

# Exit on error
set -e

echo "Starting deployment process..."

# Navigate to project root
cd /home/ubuntu/digital-product-platform

# Load environment variables
if [ -f .env ]; then
  export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
fi

# Run build script
echo "Running build script..."
bash ./deployment/scripts/build.sh

# Deploy frontend
echo "Deploying frontend..."
cd frontend/build

# In a real production environment, this would copy files to a web server
# or deploy to a cloud hosting service like AWS S3, Netlify, or Vercel
echo "Frontend deployed successfully!"

# Deploy backend
echo "Deploying backend..."
cd ../../backend

# In a real production environment, this would deploy to a server
# or cloud service like Heroku, AWS EC2, or Google Cloud Run
echo "Backend deployed successfully!"

echo "Deployment completed successfully!"
echo "Your digital product platform is now live!"
