#!/bin/bash

# Startup script for Digital Product Platform

# Exit on error
set -e

echo "Starting Digital Product Platform..."

# Navigate to project root
cd /home/ubuntu/digital-product-platform

# Load environment variables
if [ -f .env ]; then
  export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
fi

# Start backend server
echo "Starting backend server..."
cd backend
npm start &
BACKEND_PID=$!
echo "Backend server started with PID: $BACKEND_PID"

# Start frontend development server (for demo purposes)
echo "Starting frontend server..."
cd ../frontend
npm start &
FRONTEND_PID=$!
echo "Frontend server started with PID: $FRONTEND_PID"

echo "Digital Product Platform is now running!"
echo "Backend API: http://localhost:5000"
echo "Frontend: http://localhost:3000"

# Wait for both processes
wait $BACKEND_PID $FRONTEND_PID
