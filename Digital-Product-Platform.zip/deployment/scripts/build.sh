#!/bin/bash

# Production build script for Digital Product Platform

# Exit on error
set -e

echo "Starting production build process..."

# Navigate to project root
cd /home/ubuntu/digital-product-platform

# Build frontend
echo "Building frontend..."
cd frontend
npm install --production
npm run build
echo "Frontend build completed successfully!"

# Build backend
echo "Building backend..."
cd ../backend
npm install --production
echo "Backend build completed successfully!"

# Create necessary directories if they don't exist
mkdir -p uploads
mkdir -p logs

echo "Production build completed successfully!"
