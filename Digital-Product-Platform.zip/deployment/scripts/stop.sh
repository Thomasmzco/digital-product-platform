#!/bin/bash

# Shutdown script for Digital Product Platform

# Exit on error
set -e

echo "Shutting down Digital Product Platform..."

# Find and kill backend process
BACKEND_PID=$(pgrep -f "node.*backend")
if [ -n "$BACKEND_PID" ]; then
  echo "Stopping backend server (PID: $BACKEND_PID)..."
  kill $BACKEND_PID
  echo "Backend server stopped."
else
  echo "Backend server is not running."
fi

# Find and kill frontend process
FRONTEND_PID=$(pgrep -f "node.*frontend")
if [ -n "$FRONTEND_PID" ]; then
  echo "Stopping frontend server (PID: $FRONTEND_PID)..."
  kill $FRONTEND_PID
  echo "Frontend server stopped."
else
  echo "Frontend server is not running."
fi

echo "Digital Product Platform has been shut down."
