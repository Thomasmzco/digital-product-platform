# Digital Product Platform Deployment Guide

## Overview

This document provides instructions for deploying your Digital Product Platform to a production environment. The platform consists of a React frontend and a Node.js Express backend with MongoDB database integration.

## Prerequisites

Before deploying, ensure you have:

1. A server or cloud hosting account (AWS, Google Cloud, Heroku, etc.)
2. MongoDB database instance (MongoDB Atlas recommended for production)
3. Stripe account with API keys
4. Domain name (optional but recommended)

## Deployment Options

### Option 1: Traditional Server Deployment

#### Backend Deployment

1. Set up a server with Node.js installed
2. Clone the repository to your server
3. Configure environment variables in `.env` file:
   ```
   NODE_ENV=production
   PORT=5000
   MONGO_URI=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret
   JWT_EXPIRE=30d
   STRIPE_SECRET_KEY=your_stripe_secret_key
   STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
   FILE_UPLOAD_PATH=./uploads
   MAX_FILE_SIZE=10000000
   ```
4. Run the build script:
   ```
   ./deployment/scripts/build.sh
   ```
5. Set up a process manager like PM2:
   ```
   npm install -g pm2
   pm2 start backend/src/server.js --name digital-product-backend
   ```
6. Configure Nginx as a reverse proxy (sample configuration provided in `deployment/nginx.conf`)

#### Frontend Deployment

1. Build the frontend:
   ```
   cd frontend
   npm run build
   ```
2. Deploy the contents of the `frontend/build` directory to your web server
3. Configure Nginx to serve the static files (sample configuration provided in `deployment/nginx.conf`)

### Option 2: Cloud Platform Deployment

#### Heroku Deployment

1. Create a Heroku account and install the Heroku CLI
2. Create a new Heroku app:
   ```
   heroku create your-digital-product-platform
   ```
3. Add MongoDB add-on or configure environment variable for external MongoDB:
   ```
   heroku addons:create mongodb:sandbox
   ```
   or
   ```
   heroku config:set MONGO_URI=your_mongodb_connection_string
   ```
4. Configure other environment variables:
   ```
   heroku config:set NODE_ENV=production
   heroku config:set JWT_SECRET=your_jwt_secret
   heroku config:set JWT_EXPIRE=30d
   heroku config:set STRIPE_SECRET_KEY=your_stripe_secret_key
   heroku config:set STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
   ```
5. Deploy the application:
   ```
   git push heroku main
   ```

#### AWS Deployment

1. Create an AWS account
2. Set up an EC2 instance for the backend
3. Set up S3 bucket for frontend static files
4. Configure CloudFront for content delivery
5. Set up a load balancer if needed for scaling
6. Follow the traditional server deployment steps on the EC2 instance

## Database Setup

1. Create a MongoDB Atlas account or set up a MongoDB server
2. Create a new database named `digital-product-platform`
3. Set up database user with appropriate permissions
4. Configure network access to allow connections from your server
5. Use the connection string in your environment variables

## SSL Configuration

For production, always use HTTPS:

1. Obtain an SSL certificate (Let's Encrypt is a free option)
2. Configure your web server to use the SSL certificate
3. Redirect all HTTP traffic to HTTPS

## Post-Deployment Verification

After deployment, verify:

1. Frontend loads correctly
2. User registration and login work
3. Products are displayed correctly
4. Shopping cart functionality works
5. Checkout process completes successfully
6. Digital product downloads work after purchase

## Monitoring and Maintenance

1. Set up monitoring for server health (e.g., AWS CloudWatch, New Relic)
2. Configure log rotation for application logs
3. Set up regular database backups
4. Monitor Stripe dashboard for payment issues
5. Regularly update dependencies for security patches

## Scaling Considerations

As your platform grows:

1. Implement database indexing for performance
2. Consider sharding for large databases
3. Use a CDN for static assets
4. Implement caching strategies
5. Set up auto-scaling for server resources

## Troubleshooting

Common deployment issues:

1. CORS errors: Ensure API URLs are configured correctly
2. Database connection issues: Check network rules and credentials
3. File upload problems: Verify directory permissions
4. Payment processing errors: Validate Stripe configuration

For assistance with deployment, contact your system administrator or cloud provider support.
