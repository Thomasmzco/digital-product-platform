const assert = require('assert');
const Review = require('../../backend/src/models/Review');

// Unit tests for Review model
describe('Review Model Tests', () => {
  // Test review creation with valid data
  it('should create a new review with valid data', () => {
    const reviewData = {
      productId: '123456789012',
      userId: '234567890123',
      userName: 'John Doe',
      rating: 5,
      title: 'Excellent Product',
      content: 'This is an amazing product that helped me organize my finances.'
    };
    
    const review = new Review(reviewData);
    
    assert.strictEqual(review.productId.toString(), reviewData.productId);
    assert.strictEqual(review.userId.toString(), reviewData.userId);
    assert.strictEqual(review.userName, reviewData.userName);
    assert.strictEqual(review.rating, reviewData.rating);
    assert.strictEqual(review.title, reviewData.title);
    assert.strictEqual(review.content, reviewData.content);
    assert.strictEqual(review.status, 'pending'); // Default status should be pending
    assert.strictEqual(review.helpful, 0); // Default helpful count should be 0
  });
  
  // Test review validation - required fields
  it('should validate required fields', async () => {
    const review = new Review({});
    
    let validationError;
    try {
      await review.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.productId);
    assert(validationError.errors.userId);
    assert(validationError.errors.userName);
    assert(validationError.errors.rating);
    assert(validationError.errors.content);
  });
  
  // Test rating validation - min and max values
  it('should validate rating range', async () => {
    // Test rating below minimum
    let review = new Review({
      productId: '123456789012',
      userId: '234567890123',
      userName: 'John Doe',
      rating: 0, // Below minimum of 1
      content: 'This is a review.'
    });
    
    let validationError;
    try {
      await review.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.rating);
    
    // Test rating above maximum
    review = new Review({
      productId: '123456789012',
      userId: '234567890123',
      userName: 'John Doe',
      rating: 6, // Above maximum of 5
      content: 'This is a review.'
    });
    
    validationError = null;
    try {
      await review.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.rating);
  });
  
  // Test content length validation
  it('should validate content length', async () => {
    // Create a string that exceeds the maximum length
    const longContent = 'a'.repeat(1001); // Max is 1000 characters
    
    const review = new Review({
      productId: '123456789012',
      userId: '234567890123',
      userName: 'John Doe',
      rating: 5,
      content: longContent
    });
    
    let validationError;
    try {
      await review.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.content);
  });
  
  // Test status validation
  it('should validate status values', async () => {
    const review = new Review({
      productId: '123456789012',
      userId: '234567890123',
      userName: 'John Doe',
      rating: 5,
      content: 'This is a review.',
      status: 'invalid-status' // Invalid status
    });
    
    let validationError;
    try {
      await review.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.status);
  });
});
