const assert = require('assert');
const Product = require('../../backend/src/models/Product');

// Unit tests for Product model
describe('Product Model Tests', () => {
  // Test product creation with valid data
  it('should create a new product with valid data', () => {
    const productData = {
      title: 'Investment Portfolio Tracker',
      slug: 'investment-portfolio-tracker',
      description: 'Track your investments with this Excel template',
      shortDescription: 'Excel template for investment tracking',
      type: 'template',
      price: 24.99,
      fileUrl: '/uploads/investment-tracker.xlsx',
      fileSize: 1024000,
      thumbnailUrl: '/uploads/investment-tracker-thumb.jpg',
      categories: ['Finance', 'Investing'],
      tags: ['excel', 'investment', 'portfolio', 'tracker']
    };
    
    const product = new Product(productData);
    
    assert.strictEqual(product.title, productData.title);
    assert.strictEqual(product.slug, productData.slug);
    assert.strictEqual(product.description, productData.description);
    assert.strictEqual(product.type, productData.type);
    assert.strictEqual(product.price, productData.price);
    assert.strictEqual(product.fileUrl, productData.fileUrl);
    assert.strictEqual(product.fileSize, productData.fileSize);
    assert.strictEqual(product.thumbnailUrl, productData.thumbnailUrl);
    assert.deepStrictEqual(product.categories, productData.categories);
    assert.deepStrictEqual(product.tags, productData.tags);
    assert.strictEqual(product.featured, false); // Default should be false
    assert.strictEqual(product.status, 'draft'); // Default status should be draft
    assert.strictEqual(product.salesCount, 0); // Default sales count should be 0
  });
  
  // Test product validation - required fields
  it('should validate required fields', async () => {
    const product = new Product({});
    
    let validationError;
    try {
      await product.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.title);
    assert(validationError.errors.slug);
    assert(validationError.errors.description);
    assert(validationError.errors.type);
    assert(validationError.errors.price);
    assert(validationError.errors.fileUrl);
    assert(validationError.errors.fileSize);
    assert(validationError.errors.thumbnailUrl);
    assert(validationError.errors.categories);
  });
  
  // Test price validation
  it('should validate price is positive', async () => {
    const product = new Product({
      title: 'Investment Portfolio Tracker',
      slug: 'investment-portfolio-tracker',
      description: 'Track your investments with this Excel template',
      type: 'template',
      price: -10,
      fileUrl: '/uploads/investment-tracker.xlsx',
      fileSize: 1024000,
      thumbnailUrl: '/uploads/investment-tracker-thumb.jpg',
      categories: ['Finance']
    });
    
    let validationError;
    try {
      await product.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.price);
  });
  
  // Test type validation
  it('should validate product type', async () => {
    const product = new Product({
      title: 'Investment Portfolio Tracker',
      slug: 'investment-portfolio-tracker',
      description: 'Track your investments with this Excel template',
      type: 'invalid-type',
      price: 24.99,
      fileUrl: '/uploads/investment-tracker.xlsx',
      fileSize: 1024000,
      thumbnailUrl: '/uploads/investment-tracker-thumb.jpg',
      categories: ['Finance']
    });
    
    let validationError;
    try {
      await product.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.type);
  });
  
  // Test slug generation
  it('should generate slug from title', () => {
    const product = new Product({
      title: 'Investment Portfolio Tracker',
      description: 'Track your investments with this Excel template',
      type: 'template',
      price: 24.99,
      fileUrl: '/uploads/investment-tracker.xlsx',
      fileSize: 1024000,
      thumbnailUrl: '/uploads/investment-tracker-thumb.jpg',
      categories: ['Finance']
    });
    
    // Call the pre-save hook manually for testing
    product.schema.pre('save', function(next) {
      if (!this.isModified('title')) {
        next();
        return;
      }
      
      this.slug = this.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
      
      next();
    });
    
    // Simulate the pre-save hook
    const mockNext = () => {};
    product.schema.callQueue[0][1].call(product, mockNext);
    
    assert.strictEqual(product.slug, 'investment-portfolio-tracker');
  });
});
