const assert = require('assert');
const User = require('../../backend/src/models/User');

// Unit tests for User model
describe('User Model Tests', () => {
  // Test user creation with valid data
  it('should create a new user with valid data', () => {
    const userData = {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      password: 'Password123!'
    };
    
    const user = new User(userData);
    
    assert.strictEqual(user.firstName, userData.firstName);
    assert.strictEqual(user.lastName, userData.lastName);
    assert.strictEqual(user.email, userData.email);
    assert.strictEqual(user.role, 'customer'); // Default role should be customer
    assert.strictEqual(user.purchases.length, 0); // Should have empty purchases array
    assert.strictEqual(user.cart.length, 0); // Should have empty cart array
    assert.strictEqual(user.wishlist.length, 0); // Should have empty wishlist array
  });
  
  // Test user validation - required fields
  it('should validate required fields', async () => {
    const user = new User({});
    
    let validationError;
    try {
      await user.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.firstName);
    assert(validationError.errors.lastName);
    assert(validationError.errors.email);
    assert(validationError.errors.password);
  });
  
  // Test email validation
  it('should validate email format', async () => {
    const user = new User({
      firstName: 'John',
      lastName: 'Doe',
      email: 'invalid-email',
      password: 'Password123!'
    });
    
    let validationError;
    try {
      await user.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.email);
  });
  
  // Test password length validation
  it('should validate password length', async () => {
    const user = new User({
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      password: 'short'
    });
    
    let validationError;
    try {
      await user.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.password);
  });
  
  // Test cart functionality
  it('should add items to cart correctly', () => {
    const user = new User({
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      password: 'Password123!'
    });
    
    user.cart.push({
      productId: '123456789012',
      addedAt: new Date()
    });
    
    assert.strictEqual(user.cart.length, 1);
    assert.strictEqual(user.cart[0].productId.toString(), '123456789012');
  });
  
  // Test purchases functionality
  it('should add purchases correctly', () => {
    const user = new User({
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      password: 'Password123!'
    });
    
    user.purchases.push({
      productId: '123456789012',
      purchaseDate: new Date(),
      downloadCount: 0
    });
    
    assert.strictEqual(user.purchases.length, 1);
    assert.strictEqual(user.purchases[0].productId.toString(), '123456789012');
    assert.strictEqual(user.purchases[0].downloadCount, 0);
  });
  
  // Test wishlist functionality
  it('should add items to wishlist correctly', () => {
    const user = new User({
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      password: 'Password123!'
    });
    
    user.wishlist.push('123456789012');
    
    assert.strictEqual(user.wishlist.length, 1);
    assert.strictEqual(user.wishlist[0].toString(), '123456789012');
  });
});
