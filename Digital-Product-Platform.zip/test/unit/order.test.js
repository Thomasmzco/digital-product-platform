const assert = require('assert');
const Order = require('../../backend/src/models/Order');

// Unit tests for Order model
describe('Order Model Tests', () => {
  // Test order creation with valid data
  it('should create a new order with valid data', () => {
    const orderData = {
      userId: '123456789012',
      items: [
        {
          productId: '234567890123',
          title: 'Investment Portfolio Tracker',
          price: 24.99,
          currency: 'USD'
        },
        {
          productId: '345678901234',
          title: 'Budget Planner Template',
          price: 9.99,
          currency: 'USD'
        }
      ],
      totalAmount: 34.98,
      paymentMethod: 'credit-card',
      customerEmail: 'john.doe@example.com',
      customerName: 'John Doe',
      billingAddress: {
        country: 'United States'
      }
    };
    
    const order = new Order(orderData);
    
    assert.strictEqual(order.userId.toString(), orderData.userId);
    assert.strictEqual(order.items.length, 2);
    assert.strictEqual(order.items[0].title, 'Investment Portfolio Tracker');
    assert.strictEqual(order.items[1].title, 'Budget Planner Template');
    assert.strictEqual(order.totalAmount, 34.98);
    assert.strictEqual(order.paymentMethod, 'credit-card');
    assert.strictEqual(order.paymentStatus, 'pending'); // Default status should be pending
    assert.strictEqual(order.customerEmail, 'john.doe@example.com');
    assert.strictEqual(order.customerName, 'John Doe');
    assert.strictEqual(order.billingAddress.country, 'United States');
  });
  
  // Test order validation - required fields
  it('should validate required fields', async () => {
    const order = new Order({});
    
    let validationError;
    try {
      await order.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.userId);
    assert(validationError.errors.items);
    assert(validationError.errors.totalAmount);
    assert(validationError.errors.paymentMethod);
    assert(validationError.errors.customerEmail);
    assert(validationError.errors.customerName);
    assert(validationError.errors['billingAddress.country']);
  });
  
  // Test order number generation
  it('should generate order number', () => {
    const order = new Order({
      userId: '123456789012',
      items: [
        {
          productId: '234567890123',
          title: 'Investment Portfolio Tracker',
          price: 24.99,
          currency: 'USD'
        }
      ],
      totalAmount: 24.99,
      paymentMethod: 'credit-card',
      customerEmail: 'john.doe@example.com',
      customerName: 'John Doe',
      billingAddress: {
        country: 'United States'
      }
    });
    
    // Call the pre-save hook manually for testing
    order.schema.pre('save', function(next) {
      if (this.orderNumber) {
        return next();
      }
      
      // Generate a unique order number (e.g., ORD-YYYY-XXXX)
      const year = new Date().getFullYear();
      const random = 1234; // Fixed for testing
      this.orderNumber = `ORD-${year}-${random}`;
      
      next();
    });
    
    // Simulate the pre-save hook
    const mockNext = () => {};
    order.schema.callQueue[1][1].call(order, mockNext);
    
    const expectedOrderNumber = `ORD-${new Date().getFullYear()}-1234`;
    assert.strictEqual(order.orderNumber, expectedOrderNumber);
  });
  
  // Test payment status validation
  it('should validate payment status', async () => {
    const order = new Order({
      userId: '123456789012',
      orderNumber: 'ORD-2025-1234',
      items: [
        {
          productId: '234567890123',
          title: 'Investment Portfolio Tracker',
          price: 24.99,
          currency: 'USD'
        }
      ],
      totalAmount: 24.99,
      paymentMethod: 'credit-card',
      paymentStatus: 'invalid-status',
      customerEmail: 'john.doe@example.com',
      customerName: 'John Doe',
      billingAddress: {
        country: 'United States'
      }
    });
    
    let validationError;
    try {
      await order.validate();
    } catch (error) {
      validationError = error;
    }
    
    assert(validationError);
    assert(validationError.errors.paymentStatus);
  });
});
